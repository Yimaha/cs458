import requests
import utils
from nacl.signing import SigningKey  
from nacl.public import PublicKey, PrivateKey, Box
import nacl


print("Q5")

Batman_public_key = None
with open("server_public.txt") as binary_file:
    Batman_public_key = PublicKey(binary_file.read(), nacl.encoding.Base64Encoder)

sk = None

with open("my_priviate.txt") as binary_file:
    sk = PrivateKey(binary_file.read(), nacl.encoding.Base64Encoder)

box = Box(sk, Batman_public_key)



url = "https://hash-browns.cs.uwaterloo.ca/api/pke/inbox"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "recipient": "Batman", 
}

x = requests.post(url=url, headers=headers, json=body)
rawByte = utils.from_b64_raw(x.json()[0]["msg"])

plaintext = box.decrypt(rawByte)
print(plaintext.decode('utf-8'))
