import requests
import utils
import nacl

import nacl.encoding
import nacl.hash

print("Q5")


url = "https://hash-browns.cs.uwaterloo.ca/api/pke/get-key"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "user": "Batman"
}

x = requests.post(url=url, headers=headers, json=body)
print(x.text)
rawByte = utils.from_b64_raw(x.json()["pubkey"])
print(rawByte)

HASHER = nacl.hash.blake2b

digest = HASHER(rawByte, encoder=nacl.encoding.HexEncoder)
print(digest)

with open("server_public.txt", "w") as binary_file:
    binary_file.write(x.json()["pubkey"])