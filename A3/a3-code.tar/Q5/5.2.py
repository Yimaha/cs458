import requests
import utils
from nacl.public import PublicKey, PrivateKey, Box
import nacl


print("Q5")

Batman_public_key = None
with open("server_public.txt") as binary_file:
    Batman_public_key = PublicKey(binary_file.read(), nacl.encoding.Base64Encoder)

sk = PrivateKey.generate()
pk = sk.public_key

with open("my_priviate.txt", "wb") as binary_file:
    binary_file.write(sk.encode(encoder=nacl.encoding.Base64Encoder))


url = "https://hash-browns.cs.uwaterloo.ca/api/pke/set-key"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "pubkey": utils.to_b64_raw(pk.encode())
}
x = requests.post(url=url, headers=headers, json=body)


print(x.status_code)
print(x.text)


box = Box(sk, Batman_public_key)

msg = b'yahooo'

encrypted = utils.to_b64_raw(box.encrypt(msg))


url = "https://hash-browns.cs.uwaterloo.ca/api/pke/send"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "recipient": "Batman", 
    "msg": encrypted  
}

x = requests.post(url=url, headers=headers, json=body)


print(x.status_code)
print(x.text)

