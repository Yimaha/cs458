please execute in the order, later question relies on the solution of previous problem
