import requests
import utils
from nacl.signing import VerifyKey
from nacl.public import PublicKey, PrivateKey, Box
import nacl


print("Q6")

url = "https://hash-browns.cs.uwaterloo.ca/api/prekey/inbox"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "recipient": "Batman", 
}

x = requests.post(url=url, headers=headers, json=body)
rawByte = utils.from_b64_raw(x.json()[0]["msg"])

url = "https://hash-browns.cs.uwaterloo.ca/api/prekey/get-identity-key"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "user": "Batman"
}

x = requests.post(url=url, headers=headers, json=body)
verify_key = VerifyKey(utils.from_b64_raw(x.json()["pubkey"]))

with open("his_veri.txt", "w") as binary_file:
    binary_file.write(x.json()["pubkey"])



url = "https://hash-browns.cs.uwaterloo.ca/api/prekey/get-signed-prekey"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "user": "Batman"
}

x = requests.post(url=url, headers=headers, json=body)
prekey_byte = verify_key.verify(utils.from_b64_raw(x.json()["pubkey"]))
# print("verifying signature:", )

prekey = PublicKey(prekey_byte)

with open("his_prekey.txt", "wb") as binary_file:
    binary_file.write(prekey.encode(encoder=nacl.encoding.Base64Encoder))

my_private = None

with open("my_priviate.txt" ) as binary_file:
    my_private = PrivateKey(binary_file.read(), nacl.encoding.Base64Encoder)

box = Box(my_private, prekey)

plaintext = box.decrypt(rawByte)
print(plaintext.decode('utf-8'))
