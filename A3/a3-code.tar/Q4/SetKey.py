import requests
import utils
from nacl import pwhash, secret
import nacl
from nacl.signing import SigningKey  


print("Q4")

signing_key = SigningKey.generate()

# Sign a message with the signing key
# Obtain the verify key for a given signing key
verify_key = signing_key.verify_key

# Serialize the verify key to send it to a third party
print(signing_key)
# encoded = skbob.encode(encoder=nacl.encoding.Base64Encoder)
# print(encoded)
# decoded = utils.from_b64_raw(encoded)
# print(decoded)
# store secrete key for later
with open("secret.txt", "wb") as binary_file:
    binary_file.write(signing_key.encode(encoder=nacl.encoding.Base64Encoder))

pubkey = utils.to_b64_raw(verify_key.encode())


print(pubkey)
url = "https://hash-browns.cs.uwaterloo.ca/api/signed/set-key"
headers = {"Accept": "application/json", "Content-Type" : "application/json"}
body = {
    "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
    "pubkey": pubkey
}
x = requests.post(url=url, headers=headers, json=body)

print(x.status_code)
print(x.text)
