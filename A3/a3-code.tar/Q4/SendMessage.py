import requests
import utils
from nacl.signing import SigningKey  
from nacl import secret
import nacl


print("Q4")

with open("secret.txt") as binary_file:
    signing_key = SigningKey(binary_file.read(), nacl.encoding.Base64Encoder)
    signed = signing_key.sign(b"boyyyy")

    msg = utils.to_b64_raw(signed)
    print(msg)


    url = "https://hash-browns.cs.uwaterloo.ca/api/signed/send"
    headers = {"Accept": "application/json", "Content-Type" : "application/json"}
    body = {
        "api_token": "df14488ca42b4cdd09e8ceed78a0cfcdbbe1b8b6a3417841b8e6e60460f38e37",
        "recipient": "Batman", 
        "msg": msg  
    }
    x = requests.post(url=url, headers=headers, json=body)


    print(x.status_code)
    print(x.text)

